sap.ui.define(
	[
		"com/xft/hr/pem/form/step/base/controller/Main.controller",
		"com/xft/ui/comp/searchHelp/library",
		"sap/ui/core/library",
	],
	function (t, Shlp, coreLibrary) {
		"use strict";
		// Declare and initialize the counter variable

		var oValueState = coreLibrary.ValueState;

		return t.extend(
			"com.xft.hr.pem.form900step0020.controller.MainCustom", {
				initStep: function () {
					this._readFieldCat();
					this._initAppProperties900Step020();

				},
				_initAppProperties900Step020: function () {
					var bEdit01, bReadonly, bEdit, bChangeability;

					if (!this._testMethod()) {
						bEdit01 = this.getEdit()
					} else {
						this.getView().getModel("appPropertiesStep").setProperty("/Edit", true)
					}

				},

				_testMethod: function () {
					var sHash = window.location.hash;
					var sHref = window.location.href;
					var bTestTest;
					if (sHash.includes("#Test-url")) {
						bTestTest = true;
					} else {
						bTestTest = false;
					}
					return bTestTest;
				},

				nestedActionRead: function (oData, fCallback, sAction) {
					this.refreshModels();
					if (!this.getEdit()) {
						this.clearCheckFieldsForm();
					}
					fCallback(this.createResponseRead(true));
				},

				// ----------------------------VALUE HELP --------------------------------------
				// Function to read the field catalog data from the backend
				_readFieldCat: function () {
					// Get the session and component IDs from the owner component
					var sSessionId = this.getOwnerComponent().getSessionId(),
						sCompId = this.getOwnerComponent().getCompId(),
						sPathNew = "/C01Set(SessionId='" + window.encodeURIComponent(sSessionId) +
						"',CompId='" + window.encodeURIComponent(sCompId) +
						"')/S900_FieldCatSet";

					// Read the field catalog data from the backend
					this.getModel("formExt").read(sPathNew, {
						filters: [
							new sap.ui.model.Filter({
								path: "EntityName",
								operator: sap.ui.model.FilterOperator.EQ,
								value1: "S900_FieldCat",
							}),
						],
						sorters: [new sap.ui.model.Sorter("ColPos", true)],
						success: function (oData) {
							// Success callback: Handle the retrieved data and update the model

							// Set the retrieved field catalog data in the appPropertiesStep model
							this.getView().getModel("appPropertiesStep").setProperty("/FieldCat", oData.results);
							// Refresh the appPropertiesStep model to notify the changes
							this.getView().getModel("appPropertiesStep").refresh();
							// Update bindings to apply the changes in the view
							this.getView().getModel("appPropertiesStep").updateBindings(true);

							// If the field catalog data has not been loaded yet, perform additional initialization
							if (!this._bFieldCatLoaded) {
								// Mark the field catalog as loaded
								this._bFieldCatLoaded = true;
								// Perform initialization for value help requests
								this._initValueHelpRequest(oData.results);
								//this._initValueHelpRequestDropdown(oData.results);
							}

							// Close the busy dialog indicating the completion of the operation
							this.closeBusyDialog();
						}.bind(this),
						error: function (oData) {
							// Error callback: Handle errors
							// Log the error for debugging purposes
							console.error("Error occurred while fetching field catalog:", oError);

							// Display a user-friendly error message to inform the user
							sap.m.MessageBox.error("An error occurred while fetching field catalog data. Please try again later.", {
								title: "Error",
							});
							// Mark the field catalog as loaded to prevent redundant calls
							this._bFieldCatLoaded = true;

							// Close the busy dialog indicating the completion of the operation (even in error)
							this.closeBusyDialog();
						}.bind(this),
					});
				},

				_initValueHelpRequest: function (aFieldCat) {
					for (var i = 0; i < aFieldCat.length; i++) {
						if (aFieldCat[i].Dropdown === false) {
							// only for Input fields (no dropdown)

							var sIdInputControl = "id" + aFieldCat[i].Fieldname; // need to be named like thät

							if (this.getView().byId(sIdInputControl)) {
								// append search help only if input control is found

								var oInputControl = this.getView().byId(sIdInputControl);
								var sValueHelpFunction = function (oEvent) {
									var aF4Data = oEvent.getSource().F4Data;
									var oShlp = {
										F4appllayer: aF4Data.F4appllayer,
										F4shlpname: aF4Data.F4shlpname,
										F4shlptype: aF4Data.F4shlptype,
										F4shlpfield: aF4Data.F4shlpfield,
									};

									this.executeFieldValueRequest(oEvent.getSource(), oShlp);
								}.bind(this);

								oInputControl.F4Data = aFieldCat[i];
								oInputControl.setShowValueHelp(aFieldCat[i].F4availabl);
								oInputControl.attachValueHelpRequest(sValueHelpFunction); // ob das funktioniert?
							}
						}
					}
				},

				// Method to initialize value help requests for input fields based on the provided field category.
				// It attaches value help request functionality to eligible input controls.
				// Parameters:
				// - aFieldCat: An array containing field category information.
				_initValueHelpRequest: function (aFieldCat) {
					for (var i = 0; i < aFieldCat.length; i++) {
						if (aFieldCat[i].Dropdown === false) {
							// Only for Input fields (no dropdown)

							var sIdInputControl = "id" + aFieldCat[i].Fieldname; // The input control's ID must be named in a specific way.

							if (this.getView().byId(sIdInputControl)) {
								// Append search help only if the input control is found in the view.

								var oInputControl = this.getView().byId(sIdInputControl);
								var sValueHelpFunction = function (oEvent) {
									// Value help function to handle value help requests for the input control.
									// It executes a field value request using the provided F4 Data.

									var aF4Data = oEvent.getSource().F4Data;
									var oShlp = {
										F4appllayer: aF4Data.F4appllayer,
										F4shlpname: aF4Data.F4shlpname,
										F4shlptype: aF4Data.F4shlptype,
										F4shlpfield: aF4Data.F4shlpfield,
									};

									this.executeFieldValueRequest(oEvent.getSource(), oShlp);
								}.bind(this);

								oInputControl.F4Data = aFieldCat[i]; // Store the field category information in the input control for later use.
								oInputControl.setShowValueHelp(aFieldCat[i].F4availabl); // Set whether the value help is available for the input control.
								oInputControl.attachValueHelpRequest(sValueHelpFunction); // Attach the value help function to the input control's value help request event.
							}
						}
					}
				},

				// Method to create and return a suggestion binding for a value help search help.
				// Parameters:
				// - sShlpname: The name of the search help.
				// - sShlpfield: The field for which the search help suggestions are needed.
				// - sApplLayer: The application layer in which the search help is available.
				_getShlpSuggestionBinding: function (sShlpname, sShlpfield, sApplLayer) {
					// Construct the path for the suggestion binding based on the provided parameters.
					var sSuggestionPath =
						"f4>/SearchhelpSet(ApplLayer='" +
						sApplLayer +
						"',Shlpname='" +
						sShlpname +
						"',Shlptype='SH')/SearchhelpValueSet";

					// Create the suggestion binding configuration object.
					var aSuggestionBinding = {
						path: sSuggestionPath, // Set the path to the OData entity set for the search help suggestions.
						filters: [
							// Add a filter to restrict the suggestions to the specified field name.
							new sap.ui.model.Filter({
								path: "Fieldname",
								operator: sap.ui.model.FilterOperator.EQ,
								value1: sShlpfield,
							}),
						],
						parameters: {
							operationMode: sap.ui.model.odata.OperationMode.Client, // Set the operation mode to client-side filtering.
						},
						template: new sap.ui.core.ListItem({
							key: "{f4>Fieldval}", // Define the key for the ListItems from the 'Fieldval' property.
							text: "{f4>Fieldval}", // Define the text for the ListItems from the 'Fieldval' property.
						}),
						templateShareable: false, // Ensure that the template is not shared among other bindings.
					};

					// Return the suggestion binding configuration.
					return aSuggestionBinding;
				},

				executeFieldValueRequest: function (oField, oShlp) {
					var OValueMap;
					try {
						if (!oShlp) {
							return;
						}
						switch (oShlp.F4shlpfield) {
						case "AUART":
							OValueMap = {
								AUART: undefined,
							};
							if (this.getView().byId("idVmAufnr").getValue() !== "") {
								OValueMap.AUART = this.getView().byId("idVmAufnr").getValue();
							}
							break;
						default:
							break;
						}
						var oHelpDialog = Shlp.getShlpDialog(oField, oShlp, this, {
							values: OValueMap
						}, this.onDynFieldValueRequestConfirm.bind(this));
						this.getView().addDependent(this.oHelpDialog);
						if (oHelpDialog) {
							oHelpDialog.open();

						}
					} catch (Error) {
						jQuery.sap.log.error("Failed to open value request dialog.");
						jQuery.sap.log.error(Error);
						//do nothing
					}
				},

				onDynFieldValueRequestConfirm: function (oData) {
					if (oData && oData.source) {
						try {
							var oSource = oData.source;
							//var oContext = oSource.getBindingContext("formExt");
							//var sF4shlpfield = oData.F4shlpfield;
							var sFieldname = oSource.F4Data.Fieldname;
							var oValue = {};
							var sField01 = oSource.F4Data.Field01;
							var sFieldnameNewText = `id${sFieldname}Txt`;

							if (oData.values instanceof Array && oData.values.length) {
								oValue = oData.values[0];
							} else if (oData.values instanceof Object) {
								oValue = oData.values;
							}
							//Handle the field self.
							//if (oValue.value !== undefined && oValue.value !== null) {
							//	oObject[oData.sFieldname] = oValue.value;
							//	oSource.getModel().setProperty(oContext.getPath() + "/" + oData.Fieldname, oValue.value);
							//}
							//this._setModifiedField(oObject, oData.Fieldname);
							//Handle dependency fields

							var aValues = oValue.values,
								oValues;
							oValues = {};
							if (aValues instanceof Array && aValues.length) {
								oValues = aValues[0];
							} else if (aValues instanceof Object) {
								oValues = aValues;
							}
							if (oValues[sField01] !== null) {
								this.getView()
									.byId(sFieldnameNewText)
									.setText(oValues[sField01]);
							}

							if (sFieldnameNewText === "idRecruiterTxt") {
								this.updateComponentDataExt_liveChange02();
							}
						} catch (error) {
							//do nothing
						}
					}
				},

				onPressFeedback: function (oEvent) {
					var oTextArea = oEvent.getSource(),
						iValueLength = oTextArea.getValue().length,
						iMaxLength = oTextArea.getMaxLength() - 2,
						sState =
						iValueLength > iMaxLength ? oValueState.Warning : oValueState.None;
					var sWarningMessage01 = this.getView()
						.getModel("i18n")
						.getResourceBundle()
						.getText("MainView.Text.WarningMessage01");
					oTextArea.setValueState(sState);
					oTextArea.setValueStateText(sWarningMessage01);
				},

				// ----------------------------	Update ---------------------------------------

				// Method to update component data for liveChange01. 
				// This method updates the data in the formExt model and handles success and error cases.
				updateComponentDataExt_liveChange01: function () {
					var oResourceBundle = this.getView().getModel("i18n").getResourceBundle(),
						oModel = this.getModel("formExt");

					// Open a busy dialog to indicate that data is being updated.
					this.openBusyDialog();

					// Check if there are pending changes in the formExt model.
					if (oModel && oModel.hasPendingChanges()) {
						this._bUpdatedDataExist = true;

						// Submit the pending changes with a specific group ID.
						oModel.submitChanges({
							groupId: "UpdateFormExtData",
							success: function (_data, _resp) {
								// Success callback: Refresh data models and close the busy dialog.
								this.refreshModels();
								this.closeBusyDialog();
							}.bind(this),
							error: function (oError) {
								// Error callback: Handle the server error and display an error message.
								fCallback({
									allowed: false,
									messages: [oResourceBundle.getText("error.server")],
								});
								this.closeBusyDialog();
								this.displayServerError(oError);
							}.bind(this),
						});
					}
				},

				// Method to update component data for liveChange02.
				// This method updates the data in the formExt model without waiting for the response for non-relevant process information (text).
				updateComponentDataExt_liveChange02: function () {
					var oResourceBundle = this.getView().getModel("i18n").getResourceBundle(),
						oModel = this.getModel("formExt");

					// Check if there are pending changes in the formExt model.
					if (oModel && oModel.hasPendingChanges()) {
						this._bUpdatedDataExist = true;

						// Submit the pending changes with a specific group ID.
						oModel.submitChanges({
							groupId: "UpdateFormExtData",
							success: function (_data, _resp) {
								// Success callback: Refresh data models (only) without any further actions.
								this.refreshModels();
							}.bind(this),
							error: function (oError) {
								// Error callback: Handle the server error and display an error message.
								this.displayServerError(oError);
							}.bind(this),
						});
					}
				},
				// -------------------------------------------------------------------

				// ----------------------------Check ---------------------------------------

				// checkEmptySpace: function (sValue) {
				// 	// Define a regular expression to match whitespace characters
				// 	var validRegex = /\s+/g;
				// 	// Check if the given string matches the whitespace regular expression
				// 	if (sValue.match(validRegex)) {
				// 		return true; // String contains whitespace characters
				// 	}
				// 	return false; // String does not contain whitespace characters
				// },

				// validateHr: function (sInput) {
				// 	var validRegex = /^[0-9]*$/;
				// 	// Check if the input matches the regular expression
				// 	var sState = sInput.match(validRegex) ? oValueState.None : oValueState.Error;
				// 	// Check the length of the input if it's valid
				// 	if (sState === "None") {
				// 		sState = sInput.length === 3 ? oValueState.None : oValueState.Error;
				// 	}
				// 	// Return the validation state
				// 	return sState;
				// },

				// ----------------------------Check ---------------------------------------
			}
		);
	});