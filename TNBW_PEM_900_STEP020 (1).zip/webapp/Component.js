jQuery.sap.declare("com.xft.hr.pem.form900step0020.Component");
sap.ui.component.load({
	name: "com.xft.hr.pem.form.step.base",
	url: "/sap/bc/ui5_ui5/xft1/hr_pem_step"
});
this.com.xft.hr.pem.form.step.base.Component.extend("com.xft.hr.pem.form900step0020.Component", {
	metadata: {
		manifest: "json"
	},
	// redefine these getter methods for binding in view of steps

	_initAppPropertiesModel: function () {

		this.getModel("appPropertiesStep").setData({
			Edit: true,
			Changeability: true,
			Readonly: true
		});
	},
	/********************************************************************************************/
	setEdit: function (bEdit) {

		this.setProperty("edit", bEdit);
		this.getModel("appPropertiesStep").setProperty("/Edit", bEdit);
		this.getModel("appPropertiesStep").refresh();
	},

	setChangeability: function (bChangeability) {

		this.setProperty("changeability", bChangeability);
		this.getModel("appPropertiesStep").setProperty("/Changeability", bChangeability);
		this.getModel("appPropertiesStep").refresh();
	},

	setReadonly: function (bReadonly) {

		this.setProperty("readonly", bReadonly);
		this.getModel("appPropertiesStep").setProperty("/Readonly", bReadonly);
		this.getModel("appPropertiesStep").refresh();
	},

	/********************************************************************************************/

});